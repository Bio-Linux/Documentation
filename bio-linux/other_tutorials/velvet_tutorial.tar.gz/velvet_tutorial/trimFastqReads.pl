#!/usr/bin/perl
################################################
#
################################################


use strict;
use Carp;

my $usage = "Usage: $ARGV[0] <offset> <length> <output file> [<input file(s)>]!\n";
my $sOffset = $ARGV[0];
my $sLength = $ARGV[1];
my $output = $ARGV[2];	

my $errFH = *STDERR;
my $outFH = *STDOUT;
open($outFH,">>", $output) or croak "Can't open '$output': $!";

for(my $i = 3; $i < (scalar @ARGV); ++$i ){
	my $arg = $ARGV[$i];
    print $errFH "Process file ".$arg."\n";
    my $inFH;
    open(my $inFH,"<", $arg) or croak "Can't open '$arg': $!";
    processInput($inFH,$outFH);  
    close($inFH);
}



close($outFH);
close($errFH);

sub processInput(){
	my $currFH = shift;
	my $oFH = shift;
	my $iCnt = 0;	
	while(my $line = <$currFH>){
		chomp $line;
		if($iCnt%4 == 1 || $iCnt%4 == 3){
			my $tmpStr = substr($line,$sOffset,$sLength);
			print $oFH $tmpStr."\n";
		} else {
			print $oFH $line."\n";
		}
		++$iCnt;
	}	
	return;
}

